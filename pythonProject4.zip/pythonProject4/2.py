class SnowFlake:
    def __init__(self, side):
        self.side = side
        self.matrix = [['-'] * side for _ in range(side)]

    def thaw(self, steps):
        for _ in range(steps):
            for i in range(self.side):
                self.matrix[i][0] = '-'
                self.matrix[i][-1] = '-'
                self.matrix[0][i] = '-'
                self.matrix[-1][i] = '-'

    def freeze(self, n):
        new_side = self.side + 2 * n
        new_matrix = [['-'] * new_side for _ in range(new_side)]
        for i in range(self.side):
            for j in range(self.side):
                new_matrix[i + n][j + n] = self.matrix[i][j]
        self.side = new_side
        self.matrix = new_matrix

    def thicken(self):
        new_side = self.side
        new_matrix = [['-'] * new_side for _ in range(new_side)]
        for i in range(self.side):
            for j in range(self.side):
                if self.matrix[i][j] == '*':
                    new_matrix[i - 1][j] = self.matrix[i][j]
                    new_matrix[i + 1][j] = self.matrix[i][j]
                    new_matrix[i][j - 1] = self.matrix[i][j]
                    new_matrix[i][j + 1] = self.matrix[i][j]
                else:
                    new_matrix[i][j] = self.matrix[i][j]
        self.matrix = new_matrix

    def show(self):
        for row in self.matrix:
            print(' '.join(row))


# Пример использования

snowflake = SnowFlake(3)
snowflake.show()
snowflake.freeze(2)
snowflake.thaw(1)
snowflake.thicken()
snowflake.show()
