class Snow:
    def __init__(self, count):
        self.count = count

    def __add__(self, n):
        self.count += n
        return self

    def __sub__(self, n):
        self.count -= n
        return self

    def __mul__(self, n):
        self.count *= n
        return self

    def __truediv__(self, n):
        self.count /= n
        return self

    def makeSnow(self, row_count):
        snowflakes_per_row = self.count // row_count
        rows = "*" * snowflakes_per_row + "\n"
        result = rows * row_count
        return result


# Пример

snow = Snow(15)
print(snow.makeSnow(3))

snow += 5
print(snow.makeSnow(4))

snow -= 7
print(snow.makeSnow(2))
