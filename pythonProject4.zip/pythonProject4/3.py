class Robot:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.path_coordinates = [(x, y)]

    def move(self, commands):
        for command in commands:
            if command == "N" and self.y < 100:
                self.y += 1
            elif command == "S" and self.y > 0:
                self.y -= 1
            elif command == "E" and self.x < 100:
                self.x += 1
            elif command == "W" and self.x > 0:
                self.x -= 1

            self.path_coordinates.append((self.x, self.y))

        return (self.x, self.y)

    def path(self):
        return self.path_coordinates


# Пример
robot = Robot(50, 50)

robot.move("NE")

print(robot.path())
