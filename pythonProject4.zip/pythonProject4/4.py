class Talking:
    def __init__(self, name):
        self.name = name
        self.yes_count = 0
        self.no_count = 0
        self.yes_no_toggle = True

    def to_answer(self):
        if self.yes_no_toggle:
            self.yes_no_toggle = False
            self.yes_count += 1
            return "moore-moore"
        else:
            self.yes_no_toggle = True
            self.no_count += 1
            return "meow-meow"

    def number_yes(self):
        return self.yes_count

    def number_no(self):
        return self.no_count
